
int	main(void)
{	
	int retorno;
	char cadena_s1[] = "A";
	char cadena_s2[] = "a";

	retorno = ft_strcmp(cadena_s1, cadena_s2);
	printf("%i\n", retorno);	
}
