int	ft_recursive_power(int nb, int power);

int main()
{
	int	base;
	int exponente;
	int resultado;

	base = 2;
	exponente = 5;
	resultado = ft_recursive_power(base, exponente);

	return 0;
}
// *******   PROBAR LOS NEGATIVOS!!!!!!   ******** //