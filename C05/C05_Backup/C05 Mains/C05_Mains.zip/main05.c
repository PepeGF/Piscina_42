#include <stdio.h>
int main()
{
	int raiz;
	raiz = ft_sqrt(1000000);
	printf ("%i\n",raiz);
	return (raiz);
}