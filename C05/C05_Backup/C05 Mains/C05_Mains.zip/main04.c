int	ft_fibonacci(int nb);

int main()
{
	int fibo;
	fibo = ft_fibonacci(10);
	return (fibo);
}
