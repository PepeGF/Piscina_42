#include <stdio.h>

int	find_next_prime(int nb);

int main()
{
	printf("%i es primo \n",find_next_prime(100));
	return 0;
}
