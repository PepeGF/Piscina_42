/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putstr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: josgarci <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/08/18 11:38:55 by josgarci          #+#    #+#             */
/*   Updated: 2021/08/18 11:38:59 by josgarci         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <unistd.h>
void	ft_putstr(char *str)
{	
	int		i;
	char	aux;

	i = 0;
	while (str[i] != '\0')
	{	
		aux = str[i];
		write(1, &aux, 1);
		i++;
	}
}

int main()
{
	ft_putstr("Wololoooooo!");
	return 0;
}

